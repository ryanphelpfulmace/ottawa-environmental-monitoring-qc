"""Generate summary statistics CSV, formatted Excel QC workbook, and monitoring charts."""

from __future__ import annotations

import logging
import pathlib

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import openpyxl
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
import pandas as pd

from src.qc_pipeline import DEFAULT_OUTPUT_DIR, run_qc_pipeline

logger = logging.getLogger(__name__)

# Palette: Deep Environmental Navy + Slate + Muted Status Tints
NAVY = "1B365D"
SLATE = "4A607A"
ALT_ROW = "F4F7FA"
BORDER_HEX = "D0D7DE"
PASS_FILL = PatternFill("solid", fgColor="D1E7DD")
FAIL_FILL = PatternFill("solid", fgColor="F8D7DA")
WARN_FILL = PatternFill("solid", fgColor="FFF3CD")
INFO_FILL = PatternFill("solid", fgColor="CFE2FF")
HEADER_FILL = PatternFill("solid", fgColor=NAVY)
ALT_FILL = PatternFill("solid", fgColor=ALT_ROW)
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
BODY_FONT = Font(name="Calibri", size=10, color="1F2328")
BOLD_FONT = Font(name="Calibri", size=10, bold=True, color="1F2328")
THIN_BORDER = Border(
    left=Side(style="thin", color=BORDER_HEX),
    right=Side(style="thin", color=BORDER_HEX),
    top=Side(style="thin", color=BORDER_HEX),
    bottom=Side(style="thin", color=BORDER_HEX),
)


def build_summary_statistics(lab_clean: pd.DataFrame) -> pd.DataFrame:
    """Compute station x parameter summary statistics on valid Primary samples."""
    pri = lab_clean[
        (lab_clean["sample_type"] == "Primary")
        & lab_clean["station_id"].fillna("").astype(str).str.strip().ne("")
        & lab_clean["parse_status"].isin(["DETECTED", "CENSORED"])
    ].copy()

    rows = []
    group_cols = ["station_id", "matrix", "parameter", "units"]
    for (st_id, matrix, param, units), grp in pri.groupby(group_cols):
        n_total = len(grp)
        det = grp[grp["is_detected"]]["result_value"]
        n_det = len(det)
        det_freq = (n_det / n_total) * 100.0 if n_total else 0.0

        g_limit = grp["guideline_limit"].dropna().iloc[0] if grp["guideline_limit"].notna().any() else np.nan
        g_source = grp["guideline_source"].dropna().iloc[0] if grp["guideline_source"].notna().any() else ""
        n_exc = int(grp["exceeds_guideline"].sum())
        max_val = det.max() if n_det > 0 else np.nan
        exc_ratio = (max_val / g_limit) if (pd.notna(max_val) and pd.notna(g_limit) and g_limit > 0) else np.nan

        rows.append(
            {
                "station_id": st_id,
                "matrix": matrix,
                "parameter": param,
                "units": units,
                "n_samples": n_total,
                "n_detected": n_det,
                "detection_freq_pct": round(det_freq, 1),
                "min_detected": round(det.min(), 3) if n_det > 0 else np.nan,
                "max_detected": round(max_val, 3) if n_det > 0 else np.nan,
                "median_substituted": round(grp["result_value"].median(), 3),
                "mean_substituted": round(grp["result_value"].mean(), 3),
                "guideline_limit": g_limit,
                "guideline_source": g_source,
                "n_exceedances": n_exc,
                "max_vs_guideline_ratio": round(exc_ratio, 2) if pd.notna(exc_ratio) else np.nan,
                "screening_status": "EXCEEDS" if n_exc > 0 else "PASS",
            }
        )

    return pd.DataFrame(rows).sort_values(["station_id", "parameter"]).reset_index(drop=True)


def _auto_fit_columns(ws: openpyxl.worksheet.worksheet.Worksheet, skip_rows: set[int] | None = None) -> None:
    skip_rows = skip_rows or set()
    merged_multi = {
        cell.coordinate
        for rng in ws.merged_cells.ranges
        if rng.min_col != rng.max_col
        for row in ws[rng.coord]
        for cell in row
    }
    for col in ws.columns:
        max_len = 0
        for cell in col:
            if cell.row in skip_rows or cell.coordinate in merged_multi:
                continue
            val = "" if cell.value is None else str(cell.value)
            if not val.startswith("="):
                max_len = max(max_len, len(val))
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 42)


def _style_table_sheet(
    ws: openpyxl.worksheet.worksheet.Worksheet,
    df: pd.DataFrame,
    header_row: int = 1,
    numeric_formats: dict[str, str] | None = None,
) -> None:
    ws.views.sheetView[0].showGridLines = True
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    numeric_formats = numeric_formats or {}

    headers = list(df.columns)
    for col_idx, col_name in enumerate(headers, start=1):
        c = ws.cell(row=header_row, column=col_idx, value=col_name)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = THIN_BORDER
    ws.row_dimensions[header_row].height = 24

    for r_offset, (_, row) in enumerate(df.iterrows(), start=header_row + 1):
        for col_idx, col_name in enumerate(headers, start=1):
            val = row[col_name]
            if pd.isna(val):
                val = None
            c = ws.cell(row=r_offset, column=col_idx, value=val)
            c.font = BODY_FONT
            c.border = THIN_BORDER
            if r_offset % 2 == 0:
                c.fill = ALT_FILL
            if col_name in numeric_formats and val is not None:
                c.number_format = numeric_formats[col_name]
                c.alignment = Alignment(horizontal="right", vertical="center")
            elif isinstance(val, (int, float)):
                c.alignment = Alignment(horizontal="right", vertical="center")
            else:
                c.alignment = Alignment(horizontal="left", vertical="center")

    ws.freeze_panes = f"A{header_row + 1}"
    _auto_fit_columns(ws)


def export_excel_workbook(
    summary_df: pd.DataFrame,
    flags_df: pd.DataFrame,
    rpd_df: pd.DataFrame,
    lab_clean: pd.DataFrame,
    guidelines_df: pd.DataFrame,
    out_path: pathlib.Path,
) -> None:
    """Build formatted multi-sheet Excel QC summary workbook with formulas and chart."""
    wb = openpyxl.Workbook()

    # ── Sheet 1: Executive Summary ──
    ws_exec = wb.active
    ws_exec.title = "Executive Summary"
    ws_exec.views.sheetView[0].showGridLines = True
    ws_exec.page_setup.orientation = "landscape"
    ws_exec.sheet_properties.pageSetUpPr.fitToPage = True

    ws_exec.merge_cells("A1:H1")
    ws_exec["A1"] = "Ottawa Environmental & Landfill Water Quality QC Summary"
    ws_exec["A1"].font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    ws_exec["A1"].fill = HEADER_FILL
    ws_exec["A1"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_exec.row_dimensions[1].height = 30

    ws_exec.merge_cells("A2:H2")
    ws_exec["A2"] = (
        "Synthetic Demonstration Dataset | Non-Detect Rule: 0.5 x RDL substitution for summary mean/median; "
        "screening against configurable Ontario-style thresholds."
    )
    ws_exec["A2"].font = Font(name="Calibri", size=9, italic=True, color="444444")
    ws_exec.row_dimensions[2].height = 18

    # KPI Cards across A:B, C:D, E:F, G:H
    n_lab = len(lab_clean)
    n_censored = int(lab_clean["is_censored"].sum())
    n_flags = len(flags_df)
    n_exceed = int(summary_df["n_exceedances"].sum())

    kpis = [
        ("A4:B4", "Total Lab Records", "A5:B5", n_lab, "#,##0"),
        ("C4:D4", "Non-Detects (<RDL / ND)", "C5:D5", n_censored, "#,##0"),
        ("E4:F4", "QA/QC Flags Raised", "E5:F5", n_flags, "#,##0"),
        ("G4:H4", "Guideline Exceedances", "G5:H5", n_exceed, "#,##0"),
    ]
    for lbl_rng, lbl_txt, val_rng, val, num_fmt in kpis:
        ws_exec.merge_cells(lbl_rng)
        ws_exec[lbl_rng.split(":")[0]] = lbl_txt
        for r in ws_exec[lbl_rng]:
            for c in r:
                c.fill = PatternFill("solid", fgColor=SLATE)
                c.font = Font(name="Calibri", size=9, bold=True, color="FFFFFF")
                c.alignment = Alignment(horizontal="center", vertical="center")
        ws_exec.merge_cells(val_rng)
        top_cell = ws_exec[val_rng.split(":")[0]]
        top_cell.value = val
        for r in ws_exec[val_rng]:
            for c in r:
                c.font = Font(name="Calibri", size=14, bold=True, color=NAVY)
                c.alignment = Alignment(horizontal="center", vertical="center")
                c.number_format = num_fmt
                c.border = THIN_BORDER

    # Station-level summary table in A7:D13 using Excel COUNTIFS/SUMIFS formulas
    st_headers = ["Station ID", "Matrix", "Parameters Screened", "Total Exceedances"]
    for col_idx, h in enumerate(st_headers, start=1):
        c = ws_exec.cell(row=7, column=col_idx, value=h)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(horizontal="left" if col_idx <= 2 else "right", vertical="center")
        c.border = THIN_BORDER
    ws_exec.row_dimensions[7].height = 22

    stations_meta = (
        summary_df[["station_id", "matrix"]].drop_duplicates().sort_values("station_id").reset_index(drop=True)
    )
    for idx, st_row in stations_meta.iterrows():
        r = 8 + idx
        ws_exec.cell(row=r, column=1, value=st_row["station_id"]).alignment = Alignment(horizontal="left", vertical="center")
        ws_exec.cell(row=r, column=2, value=st_row["matrix"]).alignment = Alignment(horizontal="left", vertical="center")
        c_cnt = ws_exec.cell(row=r, column=3, value=f"=COUNTIF('Summary Statistics'!$A$2:$A$100, A{r})")
        c_cnt.number_format = "#,##0"
        c_cnt.alignment = Alignment(horizontal="right", vertical="center")
        c_exc = ws_exec.cell(row=r, column=4, value=f"=SUMIF('Summary Statistics'!$A$2:$A$100, A{r}, 'Summary Statistics'!$N$2:$N$100)")
        c_exc.number_format = "#,##0"
        c_exc.alignment = Alignment(horizontal="right", vertical="center")
        for col_idx in range(1, 5):
            cell = ws_exec.cell(row=r, column=col_idx)
            cell.font = BODY_FONT
            cell.border = THIN_BORDER
            if r % 2 == 0:
                cell.fill = ALT_FILL

    tot_r = 8 + len(stations_meta)
    ws_exec.cell(row=tot_r, column=1, value="Total").font = BOLD_FONT
    ws_exec.cell(row=tot_r, column=2, value="").font = BOLD_FONT
    ws_exec.cell(row=tot_r, column=3, value=f"=SUM(C8:C{tot_r-1})").number_format = "#,##0"
    ws_exec.cell(row=tot_r, column=4, value=f"=SUM(D8:D{tot_r-1})").number_format = "#,##0"
    for col_idx in range(1, 5):
        c = ws_exec.cell(row=tot_r, column=col_idx)
        c.font = BOLD_FONT
        c.border = Border(top=Side(style="thin", color=NAVY), bottom=Side(style="double", color=NAVY))

    # Embedded BarChart anchored at F7 (leaving column E as spacer)
    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.title = "Guideline Exceedances by Monitoring Station"
    chart.y_axis.title = "Exceedance Count"
    chart.x_axis.title = "Station"
    chart.width = 14
    chart.height = 8
    chart.legend = None
    data_ref = Reference(ws_exec, min_col=4, min_row=7, max_row=tot_r - 1)
    cats_ref = Reference(ws_exec, min_col=1, min_row=8, max_row=tot_r - 1)
    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats_ref)
    ws_exec.add_chart(chart, "F7")
    _auto_fit_columns(ws_exec, skip_rows={1, 2, 4, 5})

    # ── Sheet 2: Summary Statistics ──
    ws_sum = wb.create_sheet("Summary Statistics")
    _style_table_sheet(
        ws_sum,
        summary_df,
        numeric_formats={
            "n_samples": "#,##0",
            "n_detected": "#,##0",
            "detection_freq_pct": "0.0",
            "min_detected": "0.000",
            "max_detected": "0.000",
            "median_substituted": "0.000",
            "mean_substituted": "0.000",
            "guideline_limit": "0.00",
            "n_exceedances": "#,##0",
            "max_vs_guideline_ratio": "0.00",
        },
    )
    status_col = list(summary_df.columns).index("screening_status") + 1
    for r in range(2, len(summary_df) + 2):
        cell = ws_sum.cell(row=r, column=status_col)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.font = BOLD_FONT
        cell.fill = FAIL_FILL if cell.value == "EXCEEDS" else PASS_FILL

    # ── Sheet 3: QA-QC Flags ──
    ws_flags = wb.create_sheet("QA-QC Flags")
    _style_table_sheet(ws_flags, flags_df)
    if not flags_df.empty:
        for r in range(2, len(flags_df) + 2):
            c = ws_flags.cell(row=r, column=1)
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.font = BOLD_FONT
            if c.value == "CRITICAL":
                c.fill = FAIL_FILL
            elif c.value == "WARNING":
                c.fill = WARN_FILL
            else:
                c.fill = INFO_FILL

    # ── Sheet 4: Field Duplicate RPD ──
    ws_rpd = wb.create_sheet("Field Duplicate RPD")
    _style_table_sheet(
        ws_rpd,
        rpd_df,
        numeric_formats={"primary_value": "0.000", "duplicate_value": "0.000", "rpd_pct": "0.0"},
    )
    if not rpd_df.empty:
        rpd_col = list(rpd_df.columns).index("rpd_pct") + 1
        stat_col = list(rpd_df.columns).index("rpd_status") + 1
        for r in range(2, len(rpd_df) + 2):
            # Dynamic Excel formula for RPD (%) when both primary & duplicate are numeric
            ws_rpd.cell(
                row=r,
                column=rpd_col,
                value=f'=IF(AND(ISNUMBER(I{r}),ISNUMBER(J{r}),(I{r}+J{r})>0),ABS(I{r}-J{r})/AVERAGE(I{r},J{r})*100,"")',
            ).number_format = "0.0"
            sc = ws_rpd.cell(row=r, column=stat_col)
            sc.alignment = Alignment(horizontal="center", vertical="center")
            if sc.value == "FAIL (>25%)":
                sc.fill = FAIL_FILL
                sc.font = BOLD_FONT
            elif sc.value == "PASS":
                sc.fill = PASS_FILL

    # ── Sheet 5: Guidelines Config ──
    ws_guide = wb.create_sheet("Guidelines Config")
    _style_table_sheet(ws_guide, guidelines_df, numeric_formats={"guideline_limit": "0.00"})

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))
    logger.info("Saved formatted Excel workbook to %s", out_path)


def generate_charts(
    field_clean: pd.DataFrame,
    lab_clean: pd.DataFrame,
    charts_dir: pathlib.Path,
) -> list[pathlib.Path]:
    """Create publication-grade time-series and station-comparison PNG charts."""
    charts_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 10, "axes.edgecolor": "#CCCCCC", "axes.linewidth": 0.8})

    # 1. Chloride Time-Series Chart
    cl_df = lab_clean[
        (lab_clean["parameter"] == "Chloride")
        & (lab_clean["sample_type"] == "Primary")
        & lab_clean["station_id"].fillna("").astype(str).str.strip().ne("")
        & lab_clean["result_value"].notna()
    ].copy()
    cl_df["dt"] = pd.to_datetime(cl_df["sample_date"])
    cl_df = cl_df.sort_values("dt")

    fig, ax = plt.subplots(figsize=(9.5, 5.2), dpi=180)
    palette = {
        "MW-01": ("#2E7D32", "--", "o"),
        "MW-02": ("#1565C0", "-", "s"),
        "MW-03": ("#C62828", "-", "^"),
        "MW-04": ("#6A1B9A", "-.", "D"),
        "SW-01": ("#00838F", ":", "v"),
        "SW-02": ("#EF6C00", "-", "P"),
    }
    for st_id, grp in cl_df.groupby("station_id"):
        color, ls, marker = palette.get(st_id, ("#333333", "-", "o"))
        ax.plot(grp["dt"], grp["result_value"], label=st_id, color=color, linestyle=ls, marker=marker, linewidth=2, markersize=6)

    ax.axhline(250, color="#B71C1C", linestyle="--", linewidth=1.3, label="ODWQS Aesthetic Limit (250 mg/L)")
    ax.axhline(120, color="#E65100", linestyle=":", linewidth=1.3, label="CCME Aquatic Life (120 mg/L)")

    # Annotate MW-03 spike
    spike = cl_df[(cl_df["station_id"] == "MW-03") & (cl_df["result_value"] > 350)]
    if not spike.empty:
        s_row = spike.iloc[0]
        ax.annotate(
            f"MW-03 Spike\n({s_row['result_value']:.0f} mg/L)",
            xy=(s_row["dt"], s_row["result_value"]),
            xytext=(s_row["dt"] - pd.Timedelta(days=135), s_row["result_value"] - 28),
            arrowprops=dict(arrowstyle="->", color="#C62828", lw=1.2),
            fontsize=9,
            fontweight="bold",
            color="#C62828",
        )

    ax.set_title("Dissolved Chloride Concentration Across Monitoring Events (2025–2026)", fontsize=12, fontweight="bold", pad=12)
    ax.set_ylabel("Chloride (mg/L)")
    ax.set_xlabel("Sampling Event Date")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
    ax.grid(True, linestyle="--", alpha=0.35)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(loc="upper left", ncol=2, frameon=True, fontsize=8.5)
    fig.tight_layout()
    cl_path = charts_dir / "chloride_timeseries.png"
    fig.savefig(cl_path)
    plt.close(fig)

    # 2. Field Conductivity Station Comparison (Mean + Range across valid events)
    ec_df = field_clean[
        field_clean["qc_valid_record"]
        & field_clean["conductivity_us_cm"].notna()
        & (field_clean["conductivity_us_cm"] > 0)
    ].copy()

    ec_stats = (
        ec_df.groupby(["station_id", "matrix"])["conductivity_us_cm"]
        .agg(["mean", "min", "max"])
        .reset_index()
        .sort_values("station_id")
    )

    fig, ax = plt.subplots(figsize=(8.8, 4.8), dpi=180)
    colors = ["#1B365D" if m == "Groundwater" else "#00838F" for m in ec_stats["matrix"]]
    x = np.arange(len(ec_stats))
    yerr_low = ec_stats["mean"] - ec_stats["min"]
    yerr_high = ec_stats["max"] - ec_stats["mean"]

    bars = ax.bar(x, ec_stats["mean"], color=colors, width=0.58, alpha=0.9, zorder=3)
    ax.errorbar(x, ec_stats["mean"], yerr=[yerr_low, yerr_high], fmt="none", ecolor="#222222", elinewidth=1.4, capsize=5, zorder=4)

    for bar, mean_val in zip(bars, ec_stats["mean"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            max(bar.get_height() * 0.48, 120),
            f"{mean_val:,.0f}",
            ha="center",
            va="center",
            color="white",
            fontsize=9,
            fontweight="bold",
        )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"{row['station_id']}\n({m_lbl})" for m_lbl, (_, row) in [(("GW" if r['matrix'] == "Groundwater" else "SW"), (0, r)) for _, r in ec_stats.iterrows()]],
        fontsize=9.5,
    )
    ax.set_ylabel("Field Electrical Conductivity (uS/cm)")
    ax.set_title("Field Conductivity by Station: Mean & Min–Max Range (2025–2026)", fontsize=12, fontweight="bold", pad=12)
    ax.grid(axis="y", linestyle="--", alpha=0.35, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Custom legend for matrix
    from matplotlib.patches import Patch
    ax.legend(
        handles=[
            Patch(facecolor="#1B365D", label="Groundwater Well"),
            Patch(facecolor="#00838F", label="Surface Water Station"),
        ],
        loc="upper right",
        frameon=True,
    )
    fig.tight_layout()
    ec_path = charts_dir / "conductivity_well_comparison.png"
    fig.savefig(ec_path)
    plt.close(fig)

    logger.info("Generated charts: %s, %s", cl_path, ec_path)
    return [cl_path, ec_path]


def main(output_dir: pathlib.Path = DEFAULT_OUTPUT_DIR) -> None:
    qc = run_qc_pipeline(output_dir=output_dir)
    summary_df = build_summary_statistics(qc["lab_clean"])
    summary_csv = output_dir / "summary_statistics.csv"
    summary_df.to_csv(summary_csv, index=False)
    logger.info("Wrote summary statistics CSV to %s", summary_csv)

    xlsx_path = output_dir / "environmental_qc_summary.xlsx"
    export_excel_workbook(
        summary_df=summary_df,
        flags_df=qc["flags_df"],
        rpd_df=qc["rpd_df"],
        lab_clean=qc["lab_clean"],
        guidelines_df=qc["guidelines_df"],
        out_path=xlsx_path,
    )

    generate_charts(
        field_clean=qc["field_clean"],
        lab_clean=qc["lab_clean"],
        charts_dir=output_dir / "charts",
    )


if __name__ == "__main__":
    main()
