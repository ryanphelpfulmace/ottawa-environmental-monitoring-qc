"""Automated QA/QC validation and censored-data processing for water quality data."""

from __future__ import annotations

import logging
import pathlib
import re
from typing import Literal

import numpy as np
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)

NonDetectRule = Literal["half_rdl", "rdl", "zero"]

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
DEFAULT_FIELD_PATH = REPO_ROOT / "data" / "raw" / "field_logs.csv"
DEFAULT_LAB_PATH = REPO_ROOT / "data" / "raw" / "lab_results.csv"
DEFAULT_GUIDELINES_PATH = REPO_ROOT / "config" / "guidelines.csv"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "outputs"


def parse_lab_result(
    result_raw: object,
    rdl: object,
    lab_qualifier: object = "",
    non_detect_rule: NonDetectRule = "half_rdl",
) -> tuple[bool, bool, float | None, float | None, str]:
    """Parse raw lab concentration strings, handling <RDL and ND values safely.

    Returns:
        (is_detected, is_censored, numeric_reported, substituted_value, parse_status)
    """
    rdl_val: float | None = None
    try:
        if pd.notna(rdl) and str(rdl).strip() != "":
            rdl_val = float(rdl)
    except (TypeError, ValueError):
        rdl_val = None

    raw_str = "" if pd.isna(result_raw) else str(result_raw).strip()
    qual_str = "" if pd.isna(lab_qualifier) else str(lab_qualifier).strip().upper()

    if raw_str == "":
        return False, False, None, None, "MISSING"

    # Handle explicit non-detect text tokens (ND, BDL, <RDL)
    if raw_str.upper() in {"ND", "BDL", "<RDL", "< RDL", "NON-DETECT"} or qual_str in {"ND", "BDL"}:
        if rdl_val is None or rdl_val <= 0:
            return False, True, None, None, "CENSORED_NO_RDL"
        sub = _substitute_nd(rdl_val, non_detect_rule)
        return False, True, rdl_val, sub, "CENSORED"

    # Handle '<X' censored notation (e.g., '<0.5', '< 0.10')
    lt_match = re.match(r"^<\s*([+-]?\d+(?:\.\d+)?)$", raw_str)
    if lt_match:
        limit_val = float(lt_match.group(1))
        effective_rdl = rdl_val if (rdl_val is not None and rdl_val > 0) else limit_val
        sub = _substitute_nd(effective_rdl, non_detect_rule)
        return False, True, limit_val, sub, "CENSORED"

    # Standard numeric result
    try:
        num_val = float(raw_str)
    except ValueError:
        return False, False, None, None, "MALFORMED"

    if num_val < 0:
        return False, False, num_val, None, "NEGATIVE"

    return True, False, num_val, num_val, "DETECTED"


def _substitute_nd(rdl: float, rule: NonDetectRule) -> float:
    if rule == "half_rdl":
        return 0.5 * rdl
    if rule == "rdl":
        return rdl
    if rule == "zero":
        return 0.0
    raise ValueError(f"Unsupported non_detect_rule: {rule}")


def _add_flag(
    flags: list[dict],
    severity: str,
    dataset: str,
    station_id: object,
    sample_date: object,
    parameter: str,
    rule: str,
    observed_value: object,
    details: str,
) -> None:
    flags.append(
        {
            "severity": severity,
            "dataset": dataset,
            "station_id": "" if pd.isna(station_id) else str(station_id),
            "sample_date": "" if pd.isna(sample_date) else str(sample_date),
            "parameter": parameter,
            "rule": rule,
            "observed_value": "" if pd.isna(observed_value) else str(observed_value),
            "details": details,
        }
    )


def validate_field_logs(field_df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """Run missingness, range, duplicate timestamp, and temporal jump checks on field logs."""
    df = field_df.copy()
    flags: list[dict] = []

    # 1. Missing station_id or sample_date
    for idx, row in df.iterrows():
        st = str(row.get("station_id", "")).strip() if pd.notna(row.get("station_id")) else ""
        dt = str(row.get("sample_date", "")).strip() if pd.notna(row.get("sample_date")) else ""
        if st == "":
            _add_flag(
                flags,
                "CRITICAL",
                "field_logs",
                st,
                dt,
                "station_id",
                "MISSING_STATION_ID",
                "",
                f"Row {idx + 2}: Blank station_id in field log.",
            )
        if dt == "":
            _add_flag(
                flags,
                "CRITICAL",
                "field_logs",
                st,
                dt,
                "sample_date",
                "MISSING_DATE",
                "",
                f"Row {idx + 2}: Blank sample_date in field log.",
            )

    # 2. Duplicate station + date + time timestamps
    valid_ts = df[
        df["station_id"].fillna("").astype(str).str.strip().ne("")
        & df["sample_date"].fillna("").astype(str).str.strip().ne("")
    ]
    dup_mask = valid_ts.duplicated(subset=["station_id", "sample_date", "sample_time"], keep=False)
    for _, row in valid_ts[dup_mask].drop_duplicates(subset=["station_id", "sample_date", "sample_time"]).iterrows():
        _add_flag(
            flags,
            "WARNING",
            "field_logs",
            row["station_id"],
            row["sample_date"],
            "sample_time",
            "DUPLICATE_TIMESTAMP",
            row["sample_time"],
            f"Duplicate field log entry for {row['station_id']} at {row['sample_date']} {row['sample_time']}.",
        )

    # 3. Physical range checks
    numeric_cols = [
        "static_water_level_m",
        "field_ph",
        "conductivity_us_cm",
        "dissolved_oxygen_mg_l",
        "temperature_c",
        "purge_volume_l",
    ]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    for _, row in df.iterrows():
        st = row.get("station_id", "")
        dt = row.get("sample_date", "")

        ph = row["field_ph"]
        if pd.notna(ph):
            if ph < 0 or ph > 14:
                _add_flag(
                    flags,
                    "CRITICAL",
                    "field_logs",
                    st,
                    dt,
                    "field_ph",
                    "PH_OUT_OF_RANGE",
                    ph,
                    f"Impossible field pH ({ph}); must be between 0 and 14.",
                )
            elif ph < 5.5 or ph > 9.0:
                _add_flag(
                    flags,
                    "WARNING",
                    "field_logs",
                    st,
                    dt,
                    "field_ph",
                    "PH_UNUSUAL_NATURAL_RANGE",
                    ph,
                    f"Field pH ({ph}) outside typical ambient range (5.5–9.0).",
                )

        ec = row["conductivity_us_cm"]
        if pd.notna(ec) and ec <= 0:
            _add_flag(
                flags,
                "CRITICAL",
                "field_logs",
                st,
                dt,
                "conductivity_us_cm",
                "NON_POSITIVE_CONDUCTIVITY",
                ec,
                f"Conductivity ({ec} uS/cm) must be > 0.",
            )

        do_val = row["dissolved_oxygen_mg_l"]
        if pd.notna(do_val) and do_val < 0:
            _add_flag(
                flags,
                "CRITICAL",
                "field_logs",
                st,
                dt,
                "dissolved_oxygen_mg_l",
                "NEGATIVE_DISSOLVED_OXYGEN",
                do_val,
                f"Negative dissolved oxygen ({do_val} mg/L) indicates sensor/calibration error.",
            )

        swl = row["static_water_level_m"]
        if pd.notna(swl) and swl < 0:
            _add_flag(
                flags,
                "CRITICAL",
                "field_logs",
                st,
                dt,
                "static_water_level_m",
                "NEGATIVE_WATER_LEVEL",
                swl,
                f"Negative depth-to-water ({swl} m) is physically invalid.",
            )

    # 4. Temporal jump checks per station (excluding duplicate/invalid rows)
    df["_dt"] = pd.to_datetime(df["sample_date"], errors="coerce")
    clean_for_trend = df[
        df["station_id"].fillna("").astype(str).str.strip().ne("") & df["_dt"].notna()
    ].drop_duplicates(subset=["station_id", "sample_date", "sample_time"])

    for st_id, grp in clean_for_trend.sort_values("_dt").groupby("station_id"):
        grp = grp.reset_index(drop=True)
        for i in range(1, len(grp)):
            prev_ec = grp.loc[i - 1, "conductivity_us_cm"]
            curr_ec = grp.loc[i, "conductivity_us_cm"]
            if pd.notna(prev_ec) and pd.notna(curr_ec) and prev_ec > 0 and curr_ec > 0:
                pct_change = (curr_ec - prev_ec) / prev_ec
                if abs(pct_change) >= 0.50 and abs(curr_ec - prev_ec) >= 100:
                    _add_flag(
                        flags,
                        "WARNING",
                        "field_logs",
                        st_id,
                        grp.loc[i, "sample_date"],
                        "conductivity_us_cm",
                        "SHARP_TEMPORAL_JUMP",
                        curr_ec,
                        f"Conductivity jumped {pct_change:+.1%} from {prev_ec:.0f} to {curr_ec:.0f} uS/cm vs prior event.",
                    )

            prev_ph = grp.loc[i - 1, "field_ph"]
            curr_ph = grp.loc[i, "field_ph"]
            if (
                pd.notna(prev_ph)
                and pd.notna(curr_ph)
                and 0 <= prev_ph <= 14
                and 0 <= curr_ph <= 14
                and abs(curr_ph - prev_ph) >= 1.5
            ):
                _add_flag(
                    flags,
                    "WARNING",
                    "field_logs",
                    st_id,
                    grp.loc[i, "sample_date"],
                    "field_ph",
                    "SHARP_TEMPORAL_JUMP",
                    curr_ph,
                    f"Field pH shifted by {curr_ph - prev_ph:+.2f} units vs prior event ({prev_ph} -> {curr_ph}).",
                )

    df["qc_valid_record"] = (
        df["station_id"].fillna("").astype(str).str.strip().ne("")
        & df["_dt"].notna()
        & ~df.duplicated(subset=["station_id", "sample_date", "sample_time"], keep="first")
    )
    return df.drop(columns=["_dt"]), flags


def validate_lab_results(
    lab_df: pd.DataFrame,
    guidelines_df: pd.DataFrame,
    non_detect_rule: NonDetectRule = "half_rdl",
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict]]:
    """Parse censored lab results, run QA/QC checks, compute RPD, and screen guidelines."""
    df = lab_df.copy()
    flags: list[dict] = []

    parsed = [
        parse_lab_result(r["result_raw"], r["rdl"], r.get("lab_qualifier", ""), non_detect_rule)
        for _, r in df.iterrows()
    ]
    df["is_detected"] = [p[0] for p in parsed]
    df["is_censored"] = [p[1] for p in parsed]
    df["numeric_reported"] = [p[2] for p in parsed]
    df["result_value"] = [p[3] for p in parsed]
    df["parse_status"] = [p[4] for p in parsed]
    df["nd_substitution_rule"] = np.where(df["is_censored"], non_detect_rule, "none")

    logger.info(
        "Lab parsing complete (%d rows): %d detected, %d censored (rule=%s), %d malformed/negative/missing.",
        len(df),
        int(df["is_detected"].sum()),
        int(df["is_censored"].sum()),
        non_detect_rule,
        int(df["parse_status"].isin(["MALFORMED", "NEGATIVE", "MISSING", "CENSORED_NO_RDL"]).sum()),
    )

    # 1. Missing metadata & malformed/negative results
    for idx, row in df.iterrows():
        st = str(row.get("station_id", "")).strip() if pd.notna(row.get("station_id")) else ""
        dt = str(row.get("sample_date", "")).strip() if pd.notna(row.get("sample_date")) else ""
        param = str(row.get("parameter", "")).strip()

        if st == "":
            _add_flag(
                flags,
                "CRITICAL",
                "lab_results",
                st,
                dt,
                param,
                "MISSING_STATION_ID",
                row.get("sample_id", ""),
                f"Row {idx + 2}: Blank station_id for sample {row.get('sample_id', '')}.",
            )
        if row["parse_status"] == "MALFORMED":
            _add_flag(
                flags,
                "CRITICAL",
                "lab_results",
                st,
                dt,
                param,
                "MALFORMED_RESULT",
                row["result_raw"],
                f"Non-numeric lab result '{row['result_raw']}' could not be parsed.",
            )
        elif row["parse_status"] == "NEGATIVE":
            _add_flag(
                flags,
                "CRITICAL",
                "lab_results",
                st,
                dt,
                param,
                "NEGATIVE_CONCENTRATION",
                row["result_raw"],
                f"Negative concentration ({row['result_raw']} {row['units']}) is invalid.",
            )
        elif row["parse_status"] == "MISSING":
            _add_flag(
                flags,
                "CRITICAL",
                "lab_results",
                st,
                dt,
                param,
                "MISSING_RESULT",
                "",
                "Blank analytical result.",
            )

    # 2. Field Duplicate Relative Percent Difference (RPD)
    primary = df[(df["sample_type"] == "Primary") & df["station_id"].fillna("").astype(str).str.strip().ne("")]
    dups = df[(df["sample_type"] == "Field Duplicate") & df["station_id"].fillna("").astype(str).str.strip().ne("")]
    rpd_records: list[dict] = []

    merged_dups = dups.merge(
        primary,
        on=["station_id", "sample_date", "parameter", "matrix", "units"],
        suffixes=("_dup", "_pri"),
    )
    for _, row in merged_dups.iterrows():
        p_val = row["result_value_pri"]
        d_val = row["result_value_dup"]
        p_det = row["is_detected_pri"]
        d_det = row["is_detected_dup"]
        if p_det and d_det and pd.notna(p_val) and pd.notna(d_val) and (p_val + d_val) > 0:
            rpd = abs(p_val - d_val) / ((p_val + d_val) / 2.0) * 100.0
            status = "FAIL (>25%)" if rpd > 25.0 else "PASS"
            if rpd > 25.0:
                _add_flag(
                    flags,
                    "WARNING",
                    "lab_results",
                    row["station_id"],
                    row["sample_date"],
                    row["parameter"],
                    "FIELD_DUPLICATE_RPD_EXCEEDED",
                    f"{rpd:.1f}%",
                    f"Primary={p_val:.3g}, Duplicate={d_val:.3g} {row['units']} (RPD={rpd:.1f}% > 25%).",
                )
        else:
            rpd = np.nan
            status = "N/A (Non-Detect)"

        rpd_records.append(
            {
                "station_id": row["station_id"],
                "sample_date": row["sample_date"],
                "parameter": row["parameter"],
                "units": row["units"],
                "primary_sample_id": row["sample_id_pri"],
                "duplicate_sample_id": row["sample_id_dup"],
                "primary_raw": row["result_raw_pri"],
                "duplicate_raw": row["result_raw_dup"],
                "primary_value": p_val if p_det else np.nan,
                "duplicate_value": d_val if d_det else np.nan,
                "rpd_pct": round(rpd, 2) if pd.notna(rpd) else np.nan,
                "rpd_status": status,
            }
        )
    rpd_df = pd.DataFrame(rpd_records)

    # 3. Temporal Jump Checks (Primary detected results per station & parameter)
    df["_dt"] = pd.to_datetime(df["sample_date"], errors="coerce")
    valid_pri = df[
        (df["sample_type"] == "Primary")
        & df["station_id"].fillna("").astype(str).str.strip().ne("")
        & df["is_detected"]
        & df["_dt"].notna()
    ]
    for (st_id, param), grp in valid_pri.sort_values("_dt").groupby(["station_id", "parameter"]):
        grp = grp.reset_index(drop=True)
        for i in range(1, len(grp)):
            prev_val = grp.loc[i - 1, "result_value"]
            curr_val = grp.loc[i, "result_value"]
            rdl_val = grp.loc[i, "rdl"]
            if prev_val > 0 and curr_val / prev_val >= 2.0 and (curr_val - prev_val) > (2.0 * rdl_val):
                _add_flag(
                    flags,
                    "WARNING",
                    "lab_results",
                    st_id,
                    grp.loc[i, "sample_date"],
                    param,
                    "SHARP_CONCENTRATION_JUMP",
                    f"{curr_val:.3g} {grp.loc[i, 'units']}",
                    f"Concentration increased {curr_val / prev_val:.1f}x vs prior event ({prev_val:.3g} -> {curr_val:.3g} {grp.loc[i, 'units']}).",
                )

    # 4. Guideline Exceedance Screening
    df = df.merge(
        guidelines_df[["parameter", "matrix", "units", "guideline_limit", "guideline_source"]],
        on=["parameter", "matrix", "units"],
        how="left",
    )
    df["exceeds_guideline"] = (
        df["is_detected"] & df["guideline_limit"].notna() & (df["result_value"] > df["guideline_limit"])
    )

    for _, row in df[df["exceeds_guideline"] & (df["sample_type"] == "Primary")].iterrows():
        _add_flag(
            flags,
            "INFO",
            "lab_results",
            row["station_id"],
            row["sample_date"],
            row["parameter"],
            "GUIDELINE_EXCEEDANCE",
            f"{row['result_value']:.3g} {row['units']}",
            f"Exceeds {row['guideline_source']} limit of {row['guideline_limit']} {row['units']}.",
        )

    return df.drop(columns=["_dt"]), rpd_df, flags


def run_qc_pipeline(
    field_path: pathlib.Path = DEFAULT_FIELD_PATH,
    lab_path: pathlib.Path = DEFAULT_LAB_PATH,
    guidelines_path: pathlib.Path = DEFAULT_GUIDELINES_PATH,
    output_dir: pathlib.Path = DEFAULT_OUTPUT_DIR,
    non_detect_rule: NonDetectRule = "half_rdl",
) -> dict[str, pd.DataFrame]:
    """Execute full QA/QC pipeline and export qc_flags_report.csv."""
    output_dir.mkdir(parents=True, exist_ok=True)

    field_raw = pd.read_csv(field_path)
    lab_raw = pd.read_csv(lab_path)
    guidelines_df = pd.read_csv(guidelines_path)

    field_clean, field_flags = validate_field_logs(field_raw)
    lab_clean, rpd_df, lab_flags = validate_lab_results(
        lab_raw, guidelines_df, non_detect_rule=non_detect_rule
    )

    all_flags = field_flags + lab_flags
    severity_order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    flags_df = pd.DataFrame(all_flags)
    if not flags_df.empty:
        flags_df["_sev_rank"] = flags_df["severity"].map(severity_order).fillna(9)
        flags_df = flags_df.sort_values(["_sev_rank", "sample_date", "station_id"]).drop(columns=["_sev_rank"])

    flags_out = output_dir / "qc_flags_report.csv"
    flags_df.to_csv(flags_out, index=False)
    logger.info("Wrote %d QA/QC flags to %s", len(flags_df), flags_out)

    return {
        "field_clean": field_clean,
        "lab_clean": lab_clean,
        "rpd_df": rpd_df,
        "flags_df": flags_df,
        "guidelines_df": guidelines_df,
    }


if __name__ == "__main__":
    results = run_qc_pipeline()
    print(results["flags_df"]["severity"].value_counts().to_string())
