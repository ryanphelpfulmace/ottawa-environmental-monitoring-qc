# Ottawa Environmental & Landfill Water Quality QC Pipeline

An automated Python QA/QC validation and reporting pipeline for landfill groundwater and surface water monitoring programs. Designed to mirror real-world environmental consulting workflows—catching field tablet typos, handling censored lab values (`<RDL` / `ND`), verifying field duplicate precision (RPD), flagging temporal concentration jumps, and generating formatted Excel summary tables and monitoring charts without manual copy-paste errors.

> **Note:** All monitoring stations, field logs, and analytical lab results in `data/raw/` are **synthetic demonstration data** modeled after typical Ontario landfill monitoring networks (upgradient background well `MW-01`, downgradient perimeter wells `MW-02`–`MW-04`, and adjacent creek stations `SW-01`–`SW-02`).

---

## Field-to-Data Workflow

1. **Raw Field & Lab Ingestion (`data/raw/`)**
   - `field_logs.csv`: Low-flow groundwater purging and surface water field measurements (static water level, field pH, electrical conductivity, dissolved oxygen, temperature, purge volume, and field observations).
   - `lab_results.csv`: Laboratory analytical deliverables (Chloride, Ammonia as N, Nitrate as N, Dissolved Iron, Dissolved Manganese, Benzene, Toluene, Dissolved Arsenic) including lab qualifiers (`<RDL`, `ND`) and paired Field Duplicates.
2. **Automated QA/QC Validation (`src/qc_pipeline.py`)**
   - **Missing & Malformed Entry Checks**: Flags blank `station_id` / `sample_date`, non-numeric lab strings (e.g., `ERROR`), negative concentrations, out-of-range pH (`< 0` or `> 14`, plus ambient range warnings outside `5.5–9.0`), negative dissolved oxygen, and duplicate `(station_id, sample_date, sample_time)` timestamps.
   - **Censored / Detection-Limit Handling**: Parses `<X`, `<RDL`, `ND`, and `BDL` strings cleanly instead of coercing them to `NaN` or `0`. Applies a configurable substitution rule (`half_rdl` = `0.5 × RDL` by default, or `rdl` / `zero`) for summary mean/median calculations while preserving true detection frequencies.
   - **Field Duplicate Precision (RPD)**: Pairs `Primary` and `Field Duplicate` samples on `(station_id, sample_date, parameter)` and flags Relative Percent Difference (`RPD > 25%`).
   - **Temporal Jump / Outlier Detection**: Flags sharp event-to-event shifts at the same station (field conductivity `>= 50%` jump, pH shift `>= 1.5` units, or lab concentration `>= 2.0×` prior event).
   - **Guideline Exceedance Screening (`config/guidelines.csv`)**: Screens detected concentrations against configurable Ontario-style thresholds modeled after [O. Reg. 169/03 (Ontario Drinking Water Quality Standards)](https://www.ontario.ca/laws/regulation/030169) and [Ontario PWQO / CCME](https://www.ontario.ca/page/water-management-policies-guidelines-provincial-water-quality-objectives) benchmarks.
3. **Deliverable Generation (`src/generate_reports.py` → `outputs/`)**
   - `outputs/qc_flags_report.csv`: Prioritized QA/QC exception log (`CRITICAL`, `WARNING`, `INFO`).
   - `outputs/summary_statistics.csv`: Station × parameter summary table (sample count, detection frequency %, min/max detected, substituted median/mean, guideline limit, exceedance count).
   - `outputs/environmental_qc_summary.xlsx`: Multi-sheet Excel deliverable (`Executive Summary` with KPI cards, Excel `COUNTIF`/`SUMIF` formulas, and embedded chart; `Summary Statistics`; `QA-QC Flags`; `Field Duplicate RPD` with live RPD formulas; and `Guidelines Config`).
   - `outputs/charts/`: Time-series and station-comparison PNG plots (`chloride_timeseries.png`, `conductivity_well_comparison.png`).

---

## Repository Structure

```text
ottawa-environmental-monitoring-qc/
├── config/
│   └── guidelines.csv              # Configurable screening thresholds (GW & SW)
├── data/
│   └── raw/
│       ├── field_logs.csv          # Synthetic field measurements (with injected anomalies)
│       └── lab_results.csv         # Synthetic lab results (<RDL, ND, duplicates, spikes)
├── outputs/
│   ├── charts/
│   │   ├── chloride_timeseries.png
│   │   └── conductivity_well_comparison.png
│   ├── environmental_qc_summary.xlsx
│   ├── qc_flags_report.csv
│   └── summary_statistics.csv
├── src/
│   ├── __init__.py
│   ├── qc_pipeline.py              # Core QA/QC validation & RDL parsing module
│   └── generate_reports.py         # Summary tables, Excel workbook, & chart generator
├── tests/
│   └── test_qc_pipeline.py         # Unit tests for RDL parsing & field validation
├── .gitignore
├── requirements.txt
└── README.md
```

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run unit tests
python -m unittest discover -s tests -v

# 3. Run the end-to-end QC & reporting pipeline
python -m src.generate_reports
```

---

## Sample Outputs

### QA/QC Exception Summary (Synthetic Dataset)
Running `python -m src.generate_reports` on the included synthetic dataset (`38` field log rows, `304` lab records) catches:
- **6 Critical Data Errors**: `PH_OUT_OF_RANGE` (`15.2` at `MW-04`), `NEGATIVE_DISSOLVED_OXYGEN` (`-1.4 mg/L` at `SW-01`), `MALFORMED_RESULT` (`ERROR` at `MW-01`), `NEGATIVE_CONCENTRATION` (`-0.12 mg/L` at `SW-02`), and 2 `MISSING_STATION_ID` rows.
- **6 Warnings**: `DUPLICATE_TIMESTAMP` (`MW-02` tablet sync duplicate), `FIELD_DUPLICATE_RPD_EXCEEDED` (`31.9%` RPD on `MW-02` Chloride), 2 `SHARP_TEMPORAL_JUMP` field conductivity spikes, and 2 `SHARP_CONCENTRATION_JUMP` lab spikes.
- **32 Guideline Exceedances (`INFO`)**: Highlighting elevated Chloride, Ammonia, Iron, Manganese, and Arsenic at downgradient leachate-zone well `MW-03` (and Iron/Chloride at `MW-02` / `SW-02`).

### Sample Charts
- `outputs/charts/chloride_timeseries.png` — Dissolved Chloride across 2025–2026 events with ODWQS (`250 mg/L`) and CCME (`120 mg/L`) reference lines.
- `outputs/charts/conductivity_well_comparison.png` — Mean and min–max range of field electrical conductivity across groundwater wells (`MW-01`–`MW-04`) and surface water stations (`SW-01`–`SW-02`).
