"""Unit tests for the Ottawa Environmental & Landfill Water Quality QC Pipeline."""

import unittest

import pandas as pd

from src.qc_pipeline import parse_lab_result, validate_field_logs


class TestQCPipeline(unittest.TestCase):
    def test_parse_censored_less_than_rdl(self) -> None:
        det, cens, rep, sub, status = parse_lab_result(
            "<0.50", 0.50, "<RDL", non_detect_rule="half_rdl"
        )
        self.assertFalse(det)
        self.assertTrue(cens)
        self.assertEqual(rep, 0.50)
        self.assertAlmostEqual(sub, 0.25)
        self.assertEqual(status, "CENSORED")

    def test_parse_censored_nd_token(self) -> None:
        det, cens, rep, sub, status = parse_lab_result(
            "ND", 0.50, "ND", non_detect_rule="rdl"
        )
        self.assertFalse(det)
        self.assertTrue(cens)
        self.assertAlmostEqual(sub, 0.50)
        self.assertEqual(status, "CENSORED")

    def test_parse_malformed_and_negative(self) -> None:
        _, _, _, _, status_err = parse_lab_result("ERROR", 0.10)
        _, _, _, _, status_neg = parse_lab_result("-0.12", 0.05)
        self.assertEqual(status_err, "MALFORMED")
        self.assertEqual(status_neg, "NEGATIVE")

    def test_validate_field_logs_catches_ph_and_negative_do(self) -> None:
        df = pd.DataFrame(
            [
                {
                    "station_id": "MW-01",
                    "sample_date": "2026-03-24",
                    "sample_time": "09:00",
                    "matrix": "Groundwater",
                    "static_water_level_m": 3.5,
                    "field_ph": 15.2,
                    "conductivity_us_cm": 500,
                    "dissolved_oxygen_mg_l": -1.0,
                    "temperature_c": 8.0,
                    "purge_volume_l": 15.0,
                }
            ]
        )
        _, flags = validate_field_logs(df)
        rules = {f["rule"] for f in flags}
        self.assertIn("PH_OUT_OF_RANGE", rules)
        self.assertIn("NEGATIVE_DISSOLVED_OXYGEN", rules)


if __name__ == "__main__":
    unittest.main()
